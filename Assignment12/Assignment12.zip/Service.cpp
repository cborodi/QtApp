#include "Service.h"

void Service::addDogService(const string& name, const string& breed, const tm& birthDate, const int& vaccinationsCount, const string& photograph)
{
	Dog puppy{ name, breed, birthDate, vaccinationsCount, photograph };
	DogValidator dogValidator;
	dogValidator.validateDog(puppy);
	this->repo.addDog(puppy);
}

void Service::removeDogService(const string& name)
{
	vector<Dog> dogs = this->getDogsFromRepo();
	for (auto dog : dogs)
		if (dog.getName() == name)
		{
			this->repo.removeDog(dog);
			return;
		}
	throw NameNotFound("This dog is not in the list");
}

void Service::updateDogService(const string& name, const string& breed, const tm& birthDate, const int& vaccinationsCount, const string& photograph)
{
	Dog puppy{ name, breed, birthDate, vaccinationsCount, photograph };
	DogValidator dogValidator;
	dogValidator.validateDog(puppy);
	this->repo.updateDog(puppy);
}

#include <cassert>

void Service::adoptDogService(string name)
{
	vector<Dog> dogs = this->getDogsFromRepo();
	for (auto dog : dogs)
	{
		if (dog.getName() == name)
		{
			this->repo.adoptDog(dog);
			return;
		}
	}
	throw NameNotFound("This dog is not in the list");
}

tm Service::splitDate(const string& birthDate)
{
	tm returnDate;
	char duplicateString[1001];
	strcpy(duplicateString, birthDate.c_str());
	char* command_token = strtok(duplicateString, "-");
	int numberOfWords = 0;
	while (command_token != NULL)
	{
		switch (numberOfWords) {
		case 0:
			returnDate.tm_mday = atoi(command_token);
			break;
		case 1:
			returnDate.tm_mon = atoi(command_token);
			break;
		case 2:
			returnDate.tm_year = atoi(command_token);
			break;
		default:
			break;
		}
		command_token = strtok(NULL, "-");
		numberOfWords++;
	}

	return returnDate;
}

string Service::tmToString(tm date)
{
	return to_string(date.tm_mday) + "-" + to_string(date.tm_mon) + "-" + to_string(date.tm_year);
}

void Service::runDisplayAppService()
{
	repo.runDisplayApp();
}