#pragma once

#include <QtWidgets/QMainWindow>
#include "qmessagebox.h"
#include "ui_Assignment12.h"
#include "Service.h"

class Assignment12 : public QMainWindow
{
	Q_OBJECT

public:
	Assignment12(Service& service, QWidget *parent = Q_NULLPTR);

private:
	Ui::Assignment12Class ui;
	Service& service;

	void populateList();
	void populateMyList();
	void populateListModeB(std::vector<Dog> dogs);

	void connectSignalsAndSlots();

	void removeDog();
	int getSelectedIndex();
	int getSelectedIndex_modeB();

public slots:
	void addDog();
	void updateDog();
	void saveDog();
	void runMyList();
	void next();
	void filter();
};
