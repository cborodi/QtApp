#pragma once
#include "Repository.h"
#include "DogValidator.h"

class Service {
private:
	Repository& repo;
	//UserRepository userRepo;

public:
	Service(Repository& repository) : repo{ repository } {}

	//TextFileRepository& getRepo() const { return repo; }
	vector<Dog> getDogsFromRepo() { return repo.getDogs(); }
	vector<Dog> getAdoptedDogsFromRepo() { return repo.getAdoptedDogs(); }

	void addDogService(const string& name, const string& breed, const tm& birthDate, const int& vaccinationsCount, const string& photograph);
	void removeDogService(const string& name);
	void updateDogService(const string& name, const string& breed, const tm& birthDate, const int& vaccinationsCount, const string& photograph);
	void adoptDogService(string name);
	tm splitDate(const string& birthDate);
	string tmToString(tm date);

	void runDisplayAppService();

};