#pragma once
#include "domain.h"

class DogValidator
{
public:
	static void validateDog(const Dog& d);
};